batch_process <- function(dir_vec, parallel = T, return_output = F, ...) {

   if (parallel) {
     outlist <- parallel::mclapply(dir_vec, function(x) process_petri(path_to_image_set =  x, ...), mc.cores = 7)
   } else {
     outlist <- lapply(dir_vec, function(x) {
       cat(paste0('Processing ', x, '...\n'))
       process_petri(path_to_image_set =  x, ...)
     }
     )
   }

   if (return_output) {
     return(outlist)
   }

}



