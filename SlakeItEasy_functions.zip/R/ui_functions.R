# set crop box by clicking on graphics device window
set_crop <- function(npts = 2) {
  p <- locator(npts, type = "p", pch = 3, col = "red")
  p_out <- lapply(p, function(x) round(c(min(x), c(max(x)))))
  return(p_out)
}
